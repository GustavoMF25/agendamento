<?php
include "./config/config.php";
?>
<!doctype html>
<html lang="en">


    <!-- Mirrored from themesbrand.com/skote/layouts/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 30 Nov 2022 21:03:31 GMT -->
    <head>

        <meta charset="utf-8" />
        <title>Dashboard | Skote - Admin & Dashboard Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Bootstrap Css -->
        <link href="<?= BASED ?>/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?= BASED ?>/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?= BASED ?>/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body data-sidebar="dark" data-layout-mode="light">
        <div id="layout-wrapper">
            <?php include "./include/navbar.php" ?>;
            <?php include "./include/sidebarLeft.php" ?>;

            <!-- CONTEUDO PRINCIPAL -->
            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboards</a></li>
                                            <li class="breadcrumb-item active">Dashboard</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <!--Aqui entra o conteudo do site ALARIQUE-->
                        <div class="card bg-soft">
                            <!--conteudo aqui dentro, alarique-->
                            <div class="card-body"> 
                                conteudo, alarique.
                            </div>
                        </div>


                        <!-- se for dividir em colunas coloca a class row e os cards dentro, alarique-->
                        <div class="row"> 
                            <div class="col-md-4"> 
                                <div class="card bg-soft">
                                    <div class="card-body"> 
                                        Dividido em colunas, alarique.
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-8">
                                <div class="card bg-soft">
                                    <div class="card-body"> 
                                        Se fizer errado vai tomar um tapa. 
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- End Page-content -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                                <script>document.write(new Date().getFullYear())</script> © Skote.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by Themesbrand
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- FIM CONTEUDO PRINCIPAL -->
        </div>
        <?php include "./include/sidebarRight.php" ?>;

        <!-- JAVASCRIPT -->
        <script src="<?= BASED ?>assets/libs/jquery/jquery.min.js"></script>
        <script src="<?= BASED ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?= BASED ?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?= BASED ?>assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?= BASED ?>assets/libs/node-waves/waves.min.js"></script>

        <!-- apexcharts -->
        <script src="<?= BASED ?>assets/libs/apexcharts/apexcharts.min.js"></script>
        <!-- dashboard init -->
        <script src="<?= BASED ?>assets/js/pages/dashboard.init.js"></script>
        <!-- App js -->
        <script src="<?= BASED ?>assets/js/app.js"></script>
    </body>
</html>